//
//  PatientHistory.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation


class PatientHistory
{
    public private(set) var patient_id : Array<Int> = []
    public private(set) var patient_Disease : Array<String> = []
    public private(set) var patient_disease_desc : Array<String> = []
    public private(set) var date_of_admit : Array<String> = []
    public private(set) var date_of_discharge : Array<String> = []
    public private(set) var doc_id : Array<Int> = []
    
    
    //Getters
    
    func getpatient_id() -> Array<Int>
    {
        return patient_id
    }
    
    func getpatient_Disease() -> Array<String>
    {
        return patient_Disease
    }
    
    func getpatient_disease_desc() -> Array<String>
    {
        return patient_disease_desc
    }
    
    func getdate_of_admit() -> Array<String>
    {
        return date_of_admit
    }
    
    func getdate_of_discharge() -> Array<String>
    {
        return date_of_discharge
    }
    
    func getdoc_id() -> Array<Int>
    {
        return doc_id
    }
    
    
    
    //Setters
    
    func setpatient_id(_patient_id : Array<Int>)
    {
        patient_id = _patient_id
    }
    
    func setpatient_Disease(_patient_Disease : Array<String>)
    {
        patient_Disease = _patient_Disease
    }
    
    func setpatient_disease_desc(_patient_disease_desc : Array<String>)
    {
        patient_disease_desc = _patient_disease_desc
    }
    
    func setdate_of_admit(_date_of_admit : Array<String>)
    {
        date_of_admit = _date_of_admit
    }
    
    func setdate_of_discharge(_date_of_discharge : Array<String>)
    {
        date_of_discharge = _date_of_discharge
    }
    
    func setdoc_id(_doc_id : Array<Int>)
    {
        doc_id = _doc_id
    }
}
