//
//  Patient.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

public class Patient
{
    public private(set) var patient_id : Array<Int> = []
    public private(set) var patient_firstname : Array<String> = []
    public private(set) var patient_lastname : Array<String> = []
    public private(set) var patient_age : Array<Int> = []
    public private(set) var patient_gender : Array<String> = []
    public private(set) var patient_address : Array<String> = []
    public private(set) var patient_phoneno : Array<String> = []
    public private(set) var doc_id_Doctor : Array<Int> = [] //Foreign Key of Doctor Class
    public private(set) var medicine_id_Medicines : Array<Int> = [] //Foreign Key of Medicines Class
    public private(set) var room_id_Rooms : Array<Int> = [] //Foreign Key of Rooms Class
    public private(set) var date_of_arrival : Array<String> = []
    public private(set) var patient_month : Array<String> = []
    
//    func GetListOfPatients(obj : Patient)
//    {
//        var patient = obj.getpatient_firstname()
//        
//        for i in patient {
//            print(i)
//        }
//    }

    
    
    //Getters
    
    func getpatient_id() -> Array<Int>
    {
      return patient_id
    }
    
    func getpatient_firstname() -> Array<String>
    {
        return patient_firstname
    }
    
    func getpatient_lastname() -> Array<String>
    {
        return patient_lastname
    }
    
    func getpatient_age() -> Array<Int>
    {
        return patient_age
    }
    
    func getpatient_gender() -> Array<String>
    {
        return patient_gender
    }
    
    func getpatient_address() -> Array<String>
    {
        return patient_address
    }
    
    func getpatient_phoneno() -> Array<String>
    {
        return patient_phoneno
    }
    
    func getdoc_id() -> Array<Int>
    {
        return doc_id_Doctor
    }
    
    func getmedicine_id() -> Array<Int>
    {
        return medicine_id_Medicines
    }
    
    func getroom_id() -> Array<Int>
    {
        return room_id_Rooms
    }
    
    func getdate_of_arrival() -> Array<String>
    {
        return date_of_arrival
    }
    
    func getpatient_month() -> Array<String>
    {
        return patient_month
    }
    
    
    
    //Setters
    
    func setpatient_id(_patient_id : Array<Int>)
    {
        patient_id = _patient_id
    }
    
    func setpatient_firstname(_patient_firstname : Array<String>)
    {
        patient_firstname = _patient_firstname
    }
    
    func setpatient_lastname(_patient_lastname : Array<String>)
    {
         patient_lastname = _patient_lastname
    }
    
    func setpatient_age(_patient_age : Array<Int>)
    {
         patient_age = _patient_age
    }
    
    func setpatient_gender(_patient_gender : Array<String>)
    {
         patient_gender = _patient_gender
    }
    
    func setpatient_address(_patient_address : Array<String>)
    {
         patient_address = _patient_address
    }
    
    func setpatient_phoneno(_patient_phoneno : Array<String>)
    {
         patient_phoneno = _patient_phoneno
    }
    
    func setdoc_id(_doc_id : Array<Int>)
    {
         doc_id_Doctor = _doc_id
    }
    
    func setmedicine_id(_medicine_id : Array<Int>)
    {
         medicine_id_Medicines = _medicine_id
    }
    
    func setroom_id(_room_id : Array<Int>)
    {
         room_id_Rooms = _room_id
    }
    
    func setdate_of_arrival(_date_of_arrival : Array<String>)
    {
         date_of_arrival = _date_of_arrival
    }
    
    func setpatient_month(_patient_month : Array<String>)
    {
         patient_month = _patient_month
    }
}















