//
//  Employees.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Employees
{
    public private(set) var emp_id : Array<Int> = []
    public private(set) var staff_name : Array<String> = []
    public private(set) var staff_gender : Array<String> = []
    public private(set) var staff_age : Array<Int> = []
    public private(set) var staff_address : Array<String> = []
    public private(set) var staff_phoneno : Array<String> = []
    public private(set) var staff_shift : Array<String> = []
    public private(set) var staff_designation : Array<String> = []
    public private(set) var staff_status : Array<String> = []
    public private(set) var dept_id : Array<Int> = []
    
    
    //Getters
    
    func getEmp_id() -> Array<Int>
    {
        return emp_id
    }
    
    func getStaff_name() -> Array<String>
    {
        return staff_name
    }
    
    func getStaff_gender() -> Array<String>
    {
        return staff_gender
    }
    
    func getStaff_age() -> Array<Int>
    {
        return staff_age
    }
    
    func getStaff_address() -> Array<String>
    {
        return staff_address
    }
    
    func getStaff_phoneno() -> Array<String>
    {
        return staff_phoneno
    }
    
    func getStaff_shift() -> Array<String>
    {
        return staff_shift
    }
    
    func getStaff_designation() -> Array<String>
    {
        return staff_designation
    }
    
    func getStaff_status() -> Array<String>
    {
        return staff_status
    }
    
    func getDept_id() -> Array<Int>
    {
        return dept_id
    }
    
    
    
    //Setters
    
    func setEmp_id(_emp_id : Array<Int>)
    {
        emp_id = _emp_id
    }
    
    func setStaff_name(_staff_name : Array<String>)
    {
        staff_name = _staff_name
    }
    
    func setStaff_gender(_staff_gender : Array<String>)
    {
        staff_gender = _staff_gender
    }
    
    func setStaff_age(_staff_age : Array<Int>)
    {
        staff_age = _staff_age
    }
    
    func setStaff_address(_staff_address : Array<String>)
    {
        staff_address = _staff_address
    }
    
    func setStaff_phoneno(_staff_phoneno : Array<String>)
    {
        staff_phoneno = _staff_phoneno
    }
    
    func setStaff_shift(_staff_shift : Array<String>)
    {
        staff_shift = _staff_shift
    }
    
    func setStaff_designation(_staff_designation : Array<String>)
    {
        staff_designation = _staff_designation
    }
    
    func setStaff_status(_staff_status : Array<String>)
    {
        staff_status = _staff_status
    }
    
    func setDept_id(_dept_id : Array<Int>)
    {
        dept_id = _dept_id
    }    
}
