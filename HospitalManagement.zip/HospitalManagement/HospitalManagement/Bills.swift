//
//  Bills.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Bills
{
    public private(set) var bill_id : Array<Int> = []
    public private(set) var bill_datetime : Array<String> = []
    public private(set) var bill_amount : Array<String> = []
    public private(set) var bill_NoOfDays : Array<Int> = []
    public private(set) var month : Array<String> = []
    public private(set) var room_id : Array<Int> = []
    public private(set) var patient_id : Array<Int> = []
    public private(set) var doc_id : Array<Int> = []
    
    
    //Getters
    
    func getBill_id() -> Array<Int>
    {
        return bill_id
    }
    
    func getBill_datetime() -> Array<String>
    {
        return bill_datetime
    }
    
    func getBill_amount() -> Array<String>
    {
        return bill_amount
    }
    
    func getBill_NoOfDays() -> Array<Int>
    {
        return bill_NoOfDays
    }
    
    func getmonth() -> Array<String>
    {
        return month
    }
    
    func getroom_id() -> Array<Int>
    {
        return room_id
    }
    
    func getpatient_id() -> Array<Int>
    {
        return patient_id
    }
    
    func getdoc_id() -> Array<Int>
    {
        return doc_id
    }
    
    
    
    //Setters
    
    func setBill_id(_bill_id : Array<Int>)
    {
        bill_id = _bill_id
    }
    
    func setBill_datetime(_bill_datetime : Array<String>)
    {
        bill_datetime = _bill_datetime
    }
    
    func setBill_amount(_bill_amount : Array<String>)
    {
        bill_amount = _bill_amount
    }
    
    func setBill_NoOfDays(_bill_NoOfDays : Array<Int>)
    {
        bill_NoOfDays = _bill_NoOfDays
    }
    
    func setmonth(_month : Array<String>)
    {
        month = _month
    }
    
    func setroom_id(_room_id : Array<Int>)
    {
        room_id = _room_id
    }
    
    func setpatient_id(_patient_id : Array<Int>)
    {
        patient_id = _patient_id
    }
    
    func setdoc_id(_doc_id : Array<Int>)
    {
        doc_id = _doc_id
    }
}
