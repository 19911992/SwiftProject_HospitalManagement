//
//  Doctors.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Doctors
{
    public private(set) var doc_id : Array<Int> = []
    public private(set) var doc_firstname : Array<String> = []
    public private(set) var doc_lastname : Array<String> = []
    public private(set) var doc_age : Array<Int> = []
    public private(set) var doc_gender : Array<String> = []
    public private(set) var doc_address : Array<String> = []
    public private(set) var doc_phoneno : Array<String> = []
    public private(set) var doc_specialization : Array<String> = []
    public private(set) var dept_id : Array<Int> = []
    public private(set) var doc_night_shift : Array<String> = []
    public private(set) var doc_day_shift : Array<String> = []
    
    //Getters
    
    func getDoctor_id() -> Array<Int>
    {
        return doc_id
    }
    
    func getDoctor_firstname() -> Array<String>
    {
        return doc_firstname
    }
    
    func getDoctor_lastname() -> Array<String>
    {
        return doc_lastname
    }
    
    func getDoctor_age() -> Array<Int>
    {
        return doc_age
    }
    
    func getDoctor_gender() -> Array<String>
    {
        return doc_gender
    }
    
    func getDoctor_address() -> Array<String>
    {
        return doc_address
    }
    
    func getDoctor_phoneno() -> Array<String>
    {
        return doc_phoneno
    }
    
    func getDoctor_specialization() -> Array<String>
    {
        return doc_specialization
    }
    
    func getDoctor_dept_id() -> Array<Int>
    {
        return dept_id
    }
    
    func getDoctor_night_shift() -> Array<String>
    {
        return doc_night_shift
    }
    
    func getDoctor_day_shift() -> Array<String>
    {
        return doc_day_shift
    }
    
    
    
    //Setters
    
    func setDoctor_id(_doc_id : Array<Int>)
    {
         doc_id = _doc_id
    }
    
    func setDoctor_firstname(_doc_firstname : Array<String>)
    {
         doc_firstname = _doc_firstname
    }
    
    func setDoctor_lastname(_doc_lastname : Array<String>)
    {
         doc_lastname = _doc_lastname
    }
    
    func setDoctor_age(_doc_age : Array<Int>)
    {
         doc_age = _doc_age
    }
    
    func setDoctor_gender(_doc_gender : Array<String>)
    {
        doc_gender = _doc_gender
    }
    
    func setDoctor_address(_doc_address : Array<String>)
    {
        doc_address = _doc_address
    }
    
    func setDoctor_phoneno(_doc_phoneno : Array<String>)
    {
        doc_phoneno = _doc_phoneno
    }
    
    func setDoctor_specialization(_doc_specialization : Array<String>)
    {
        doc_specialization = _doc_specialization
    }
    
    func setDoctor_dept_id(_doc_dept_id : Array<Int>)
    {
        dept_id = _doc_dept_id
    }
    
    func setDoctor_night_shift(_doc_night_shift : Array<String>)
    {
        doc_night_shift = _doc_night_shift
    }
    
    func setDoctor_day_shift(_doc_day_shift : Array<String>)
    {
        doc_day_shift = _doc_day_shift
    }
}



