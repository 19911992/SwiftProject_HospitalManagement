//
//  Diagnosis.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Diagnosis
{
    public private(set) var diagnosis_id : Array<Int> = []
    public private(set) var diagnosis_name : Array<String> = []
    public private(set) var diagnosis_remarks : Array<String> = []
    public private(set) var diagnosis_date : Array<String> = []
    public private(set) var diagnosis_status : Array<String> = []
    public private(set) var patient_id : Array<Int> = []
    public private(set) var doc_id : Array<Int> = []

    //Getters
    
    func getDiagnosis_id() -> Array<Int>
    {
        return diagnosis_id
    }
    
    func getDiagnosis_name() -> Array<String>
    {
        return diagnosis_name
    }
    
    func getDiagnosis_remarks() -> Array<String>
    {
        return diagnosis_remarks
    }
    
    func getDiagnosis_date() -> Array<String>
    {
        return diagnosis_date
    }
    
    func getDiagnosis_status() -> Array<String>
    {
        return diagnosis_status
    }
    
    func getPatient_id() -> Array<Int>
    {
        return patient_id
    }
    
    func getDoc_id() -> Array<Int>
    {
        return doc_id
    }
    
    
    //Setters
    
    func setDiagnosis_id(_diagnosis_id : Array<Int>)
    {
        diagnosis_id = _diagnosis_id
    }
    
    func setDiagnosis_name(_diagnosis_name : Array<String>)
    {
        diagnosis_name = _diagnosis_name
    }
    
    func setDiagnosis_remarks(_diagnosis_remarks : Array<String>)
    {
        diagnosis_remarks = _diagnosis_remarks
    }
    
    func setDiagnosis_date(_diagnosis_date : Array<String>)
    {
        diagnosis_date = _diagnosis_date
    }
    
    func setDiagnosis_status(_diagnosis_status : Array<String>)
    {
        diagnosis_status = _diagnosis_status
    }
    
    func setPatient_id(_patient_id : Array<Int>)
    {
        patient_id = _patient_id
    }
    
    func setDoc_id(_doc_id : Array<Int>)
    {
        doc_id = _doc_id
    }
}
