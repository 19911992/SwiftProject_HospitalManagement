//
//  Reports.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-12.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Reports
{    
    func commonFuncForReports(roomsobj : Rooms, docObj : Doctors, docDept : EmployeesDepartment, billObj :Bills, obj : Patient, reportChoice : Int)
    {
        if(reportChoice == 0)
        {
            print("Please enter value between 1 to 5 in below 'REPORT CHOICE' variable to see the reports.")
        }
        else if(reportChoice == 1)
        {
            //Report 1) Number of available rooms according to date ?
            
            var availableDates = ""
            var counter : Int = 0
            
            let wholeObjectCount = roomsObj.getRoom_status().count
            
            var roomStatus = roomsObj.getRoom_status()
            var roomDate = roomsObj.getRoom_date()
            
            for i in 0..<wholeObjectCount
            {
                if(roomStatus[i] == "Vacant")
                {
                    counter += 1
                    availableDates += "\t\(roomDate[i])"
                }
            }
            
            print("Number of Available rooms are: \(counter) \nDates are: \(availableDates)")
        }
        else if(reportChoice == 2)
        {
            //Report 2) Generate a report which gets Doctor Name, doctor’s department and doctor's specialization ?
            
            var docName = docObj.doc_firstname
            var docSpecializtion = docObj.doc_specialization
            var docDeptName = docDept.dept_name
            var depid = docObj.dept_id
            
            for i in 0..<docName.count
            {
                let j = depid[i]
                print("\n\nDoctor Name: \(docName[i]) \nDoctor Department: \(docDeptName[j]) \nDoctor Specialization: \(docSpecializtion[i])")
            }
        }
        else if(reportChoice == 3)
        {
            //Report 3) Total Number of doctors for the day and night shifts?
            
            var dayShiftList : [String] = []
            var nightShiftList : [String] = []
                        
            let doctorID = docObj.doc_id.count
            var docNightShift = docObj.doc_night_shift
            
            for i in 0..<doctorID
            {
                if(docNightShift[i] == "Night")
                {
                    nightShiftList.append("")
                }
                else
                {
                    dayShiftList.append("")
                }
            }
            
            print("Doctors count for night shift: \(nightShiftList.count) \nDoctors count for day shift: \(dayShiftList.count)")
        }
        else if(reportChoice == 4)
        {
            //Report 4) Generate report includes month and total revenue in that month?
            
            print("MONTH\t\t\tTOTAL REVENUE")
            
            for i in 0..<billsObj.month.count
            {
                print("\(billsObj.month[i])\t\t\t\t\(billsObj.bill_amount[i])")
            }
        }
        else if(reportChoice == 5)
        {
            //Report 5) Generate report includes Date and No. of Patients?
            
            let arrivalDateOfPatient = obj.date_of_arrival
            
            var count:[String:Int]=[:]
            for i in arrivalDateOfPatient
            {
                count[i]=(count[i] ?? 0) + 1
            }
            
            print("Date\t\t\tPatient Count")
            for(key,value) in count{
                print("\(key)\t\t\t\(value)")
            }
        }
    }
}
