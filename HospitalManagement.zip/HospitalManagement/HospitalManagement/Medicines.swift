//
//  Medicines.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Medicines
{
    public private(set) var medicine_id : Array<Int> = []
    public private(set) var medicine_name : Array<String> = []
    public private(set) var medicine_quantity : Array<String> = []
    public private(set) var medicine_price : Array<Int> = []
    
    //Getters
    
    func getMedicine_id() -> Array<Int>
    {
        return medicine_id
    }
    
    func getMedicine_name() -> Array<String>
    {
        return medicine_name
    }
    
    func getMedicine_quantity() -> Array<String>
    {
        return medicine_quantity
    }
    
    func getMedicine_price() -> Array<Int>
    {
        return medicine_price
    }

    
    
    //Setters
    
    func setMedicine_id(_pat_medicine_id : Array<Int>)
    {
         medicine_id = _pat_medicine_id
    }
    
    func setMedicine_name(_pat_medicine_name : Array<String>)
    {
         medicine_name = _pat_medicine_name
    }
    
    func setMedicine_quantity(_pat_medicine_quantity : Array<String>)
    {
         medicine_quantity = _pat_medicine_quantity
    }
    
    func setMedicine_price(_pat_medicine_price : Array<Int>)
    {
         medicine_price = _pat_medicine_price
    }
}




