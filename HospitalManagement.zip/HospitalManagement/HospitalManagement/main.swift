//  main.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

//Patient Class
var patientObj = Patient()
patientObj.setpatient_id(_patient_id: [1,2,3])
patientObj.setpatient_firstname(_patient_firstname: ["Vishal", "Guru", "Puneet"])
patientObj.setpatient_lastname(_patient_lastname: ["Verma", "Patel", "Kishore"])
patientObj.setpatient_age(_patient_age: [25, 26, 25])
patientObj.setpatient_gender(_patient_gender: ["M", "M", "M"])
patientObj.setpatient_address(_patient_address: ["Hno 37", "Hno 38", "Hno 39"])
patientObj.setpatient_phoneno(_patient_phoneno: ["6477842613", "6477847813", "6477842689"])
patientObj.setdoc_id(_doc_id: [1,2,1])
patientObj.setmedicine_id(_medicine_id: [2,1,4])
patientObj.setroom_id(_room_id: [3,2,3])
patientObj.setdate_of_arrival(_date_of_arrival: ["2017-01-10", "2017-01-10", "2017-03-16"])
patientObj.setpatient_month(_patient_month: ["01","02", "03"])


//Doctors Class
var doctorsObj = Doctors()
doctorsObj.setDoctor_id(_doc_id : [1,2,3])
doctorsObj.setDoctor_firstname(_doc_firstname : ["Dave", "Dwayne", "Katie"])
doctorsObj.setDoctor_lastname(_doc_lastname : ["Smith", "Seid", "Marlow"])
doctorsObj.setDoctor_age(_doc_age : [35,30,22])
doctorsObj.setDoctor_gender(_doc_gender : ["M", "M", "F"])
doctorsObj.setDoctor_address(_doc_address : ["1 Albion Drive" ,"3 Kittiwake Avenue", "9 Kiskadee"])
doctorsObj.setDoctor_phoneno(_doc_phoneno : ["6477774354", "6767676764", "6867687642"])
doctorsObj.setDoctor_specialization(_doc_specialization : ["Surgeon", "Surgeon", "Orthopaedic"])
doctorsObj.setDoctor_dept_id(_doc_dept_id : [2,1,3])
doctorsObj.setDoctor_night_shift(_doc_night_shift : ["", "", "Night"])
doctorsObj.setDoctor_day_shift(_doc_day_shift : ["Day", "Day", ""])


//Diagnosis Class
var diagnosisObj = Diagnosis()
diagnosisObj.setDiagnosis_id(_diagnosis_id : [1,2,3])
diagnosisObj.setDiagnosis_name(_diagnosis_name : ["Hepatitis A", "Liver Blood Test", "Heart Rhythm Disorders"])
diagnosisObj.setDiagnosis_remarks(_diagnosis_remarks : ["Serious Situation", "Normal Case", "Normal Case"])
diagnosisObj.setDiagnosis_date(_diagnosis_date : ["2017-01-11", "2017-02-08", "2017-03-15"])
diagnosisObj.setDiagnosis_status(_diagnosis_status : ["In Observation", "In Observation", "Discharged"])
diagnosisObj.setPatient_id(_patient_id : [1,2,3])
diagnosisObj.setDoc_id(_doc_id : [2,2,3])


//Bills Class
var billsObj = Bills()
billsObj.setBill_id(_bill_id : [1,2,3])
billsObj.setBill_datetime(_bill_datetime : ["2017-01-15", "2017-02-18", "2017-03-20"])
billsObj.setBill_amount(_bill_amount : ["750", "400", "300"])
billsObj.setBill_NoOfDays(_bill_NoOfDays : [5,5,2])
billsObj.setmonth(_month : ["01", "02", "03"])
billsObj.setroom_id(_room_id : [3,2,3])
billsObj.setpatient_id(_patient_id : [1,2,3])
billsObj.setdoc_id(_doc_id : [1,2,1])


//Employees Class
var employeesObj = Employees()
employeesObj.setEmp_id(_emp_id : [1,2,3])
employeesObj.setStaff_name(_staff_name : ["Laura", "Justin", "Maxime"])
employeesObj.setStaff_gender(_staff_gender : ["F", "M", "M"])
employeesObj.setStaff_age(_staff_age : [25,27,28])
employeesObj.setStaff_address(_staff_address : ["Finch", "Kiskadee", "Martin Grove"])
employeesObj.setStaff_phoneno(_staff_phoneno : ["6465642903", "6489842613", "6452642013"])
employeesObj.setStaff_shift(_staff_shift : ["Day", "Night", "Night"])
employeesObj.setStaff_designation(_staff_designation : ["Assistant", "Ward Boy", "Ward Boy"])
employeesObj.setStaff_status(_staff_status : ["Available", "Available", "Available"])
employeesObj.setDept_id(_dept_id : [2,4,5])


//PatientHistory Class
var patienthistoryObj = PatientHistory()
patienthistoryObj.setpatient_id(_patient_id : [1,2,3])
patienthistoryObj.setpatient_Disease(_patient_Disease : ["Hepatitis A", "Liver Blood Test", "Heart Rhythm Loss"])
patienthistoryObj.setpatient_disease_desc(_patient_disease_desc : ["Serious Problem", "Serious Problem", "Serious Problem"])
patienthistoryObj.setdate_of_admit(_date_of_admit : ["2017-01-08", "2017-02-11", "2017-03-07"])
patienthistoryObj.setdate_of_discharge(_date_of_discharge : ["2017-01-15", "2017-02-19", "2017-03-18"])
patienthistoryObj.setdoc_id(_doc_id : [1,2,1])


//Rooms Class
var roomsObj = Rooms()
roomsObj.setRoom_id(_room_id : [1,2,3])
roomsObj.setRoom_number(_room_number : [101,102,103])
roomsObj.setRoom_status(_room_status : ["Vacant", "Occupied", "Vacant"])
roomsObj.setRoom_charges(_room_charges : ["150", "150", "100"])
roomsObj.setRoom_date(_date : ["2017-01-09", "2017-02-05", "2017-03-10"])
roomsObj.setPatient_id(_patient_id : [1,2,3])


//Medicines Class
var medicinesObj = Medicines()
medicinesObj.setMedicine_id(_pat_medicine_id : [1,2,3,4,5])
medicinesObj.setMedicine_name(_pat_medicine_name : ["Paracetamol", "Disprin", "Solvin Cold", "Revital", "Bruffin"])
medicinesObj.setMedicine_quantity(_pat_medicine_quantity : ["50","40","30", "20", "25"])
medicinesObj.setMedicine_price(_pat_medicine_price : [35,40,45,35,30])


//EmployeesDepartment Class
var employeesdepartmentObj = EmployeesDepartment()
employeesdepartmentObj.setDept_id(_department_Id : [1,2,3,4,5])
employeesdepartmentObj.setDept_Name(_department_Name : ["Critical Care", "Diagnostic Imaging", "Elderly Services Department", "Surgery", "ENT"])


//Reports Class
var reportsObject = Reports()
reportsObject.commonFuncForReports(roomsobj : roomsObj, docObj : doctorsObj, docDept : employeesdepartmentObj, billObj :billsObj, obj : patientObj, reportChoice : 1)








