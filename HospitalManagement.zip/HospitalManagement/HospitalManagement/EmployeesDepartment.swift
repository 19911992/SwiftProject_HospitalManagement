//
//  EmployeesDepartment.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class EmployeesDepartment
{
    public private(set) var dept_id : Array<Int> = []
    public private(set) var dept_name : Array<String> = []
    
    //Getters
    
    func getDept_id() -> Array<Int>
    {
        return dept_id
    }
    
    func getDept_Name() -> Array<String>
    {
        return dept_name
    }
    
    
    
    //Setters
    
    func setDept_id(_department_Id : Array<Int>)
    {
        dept_id = _department_Id
    }
    
    func setDept_Name(_department_Name : Array<String>)
    {
        dept_name = _department_Name
    }
}
