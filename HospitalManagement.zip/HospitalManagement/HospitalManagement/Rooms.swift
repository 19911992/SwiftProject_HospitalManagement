//
//  Rooms.swift
//  HospitalManagement
//
//  Created by Vishal Verma on 2017-10-11.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation

class Rooms
{
    public private(set) var room_id : Array<Int> = []
    public private(set) var room_number : Array<Int> = []
    public private(set) var room_status : Array<String> = []
    public private(set) var room_charges : Array<String> = []
    public private(set) var date : Array<String> = []
    public private(set) var patient_id_Patient : Array<Int> = [] //Foreign Key of Patient Class

    //Getters
    
    func getRoom_id() -> Array<Int>
    {
        return room_id
    }
    
    func getRoom_number() -> Array<Int>
    {
        return room_number
    }
    
    func getRoom_status() -> Array<String>
    {
        return room_status
    }
    
    func getRoom_charges() -> Array<String>
    {
        return room_charges
    }
    
    func getRoom_date() -> Array<String>
    {
        return date
    }
    
    func getPatient_id() -> Array<Int>
    {
        return patient_id_Patient
    }
    
    
    //Setters
    
    func setRoom_id(_room_id : Array<Int>)
    {
         room_id = _room_id
    }
    
    func setRoom_number(_room_number : Array<Int>)
    {
        room_number = _room_number
    }
    
    func setRoom_status(_room_status : Array<String>)
    {
         room_status = _room_status
    }
    
    func setRoom_charges(_room_charges : Array<String>)
    {
         room_charges = _room_charges
    }
    
    func setRoom_date(_date : Array<String>)
    {
         date = _date
    }
    
    func setPatient_id(_patient_id : Array<Int>)
    {
         patient_id_Patient = _patient_id
    }
}
